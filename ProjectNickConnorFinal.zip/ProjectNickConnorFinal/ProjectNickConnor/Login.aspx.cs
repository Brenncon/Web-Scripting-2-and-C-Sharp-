﻿using ProjectNickConnor.Logic.App_Data;
using ProjectNickConnor.Logic.App_Data.RegistrationDBDataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace ProjectNickConnor
{
    public partial class Login : System.Web.UI.Page
    {
        private RegisterTableAdapter _tableAdapter = new RegisterTableAdapter();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BSubmit_Click(object sender, EventArgs e)
        {
            RegistrationDBDataSet.RegisterDataTable rows = _tableAdapter.GetDataByName(TxtUserName.Text);
            if (rows.Count == 1)
            {
                Response.Redirect("ReservationForm.aspx", false);
            }
            else
            {
                LblStatus.Text = "Login failed";
            }
        }
    }
}