﻿using ProjectNickConnor.Logic.App_Data;
using ProjectNickConnor.Logic.App_Data.ReservationDBDataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

//Author Connor Brennan

namespace ProjectNickConnor.Logic
{
    /// <summary>
    /// This class allows the various forms to add, edit, view, and cancel
    /// reservations currently in the Reservation Database
    /// </summary>
    public class Reservation
    {

        /// <summary>
        /// creates instances for the reservation table adapter 
        /// as well as the reservation data set
        /// </summary>
        private ReservationTableAdapter _ReservationAdapter = new ReservationTableAdapter();
        private ReservationDBDataSet _reservationDataSet = new ReservationDBDataSet();

        /// <summary>
        /// This method receives a name, start date and an end date, then
        /// creates a new row in the Reservation Database and adds the new 
        /// data into the newly created row. Except for the ID as it 
        /// auto increments by one for each new row. 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="startdate"></param>
        /// <param name="enddate"></param>
        public void ReserveRoom(string name, DateTime startdate, DateTime enddate)
        {
            ReservationDBDataSet.ReservationRow reservation;
            reservation = _reservationDataSet.Reservation.NewReservationRow();
            //reservation.ReservationName = name;
            reservation.ReservationStartDate = startdate;
            reservation.ReservationEndDate = enddate;
            reservation.Status = "Open";

            this._reservationDataSet.Reservation.Rows.Add(reservation);

            this._ReservationAdapter.Update(this._reservationDataSet.Reservation);
        }

        /// <summary>
        /// This method receives a new name, start date, end date, and the ID of the 
        /// reservation to be changed. The method takes the id and subtracts itself by 1
        /// to get the position of the row in the table, then adds the new data into the
        /// database table at the specified row ids position.
        /// </summary>
        /// <param name="rowid"></param>
        /// <param name="name"></param>
        /// <param name="startdate"></param>
        /// <param name="enddate"></param>
        public void EditReservation(int rowid, string name, DateTime startdate, DateTime enddate)
        {
            rowid = rowid - 1;

            DataTable table = new DataTable("Reservation");

            table.Rows[rowid]["ReservationName"] = name;
            table.Rows[rowid]["ReservationStartDate"] = startdate;
            table.Rows[rowid]["ReservationEndDate"] = enddate;
        }

        /// <summary>
        /// This method receives a row id and changes the reservation status to be 
        /// cancelled at the specified row ids position.
        /// </summary>
        /// <param name="rowid"></param>
        public void CancelReservation(int rowid)
        {
            rowid = rowid - 1;

            DataTable table = new DataTable("Reservation");

            table.Rows[rowid]["Status"] = "Cancelled";
        }

        /// <summary>
        /// This method receives a data grid view instance and sets the content
        /// of said instance to be that of the contents of the Reservation database table.
        /// </summary>
        /// <param name="dataGridView1"></param>
        public void SeeAllReservation(DataGridView dataGridView1)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = _reservationDataSet.Tables["Reservation"];

            dataGridView1.DataSource = bs;
        }
    }
}