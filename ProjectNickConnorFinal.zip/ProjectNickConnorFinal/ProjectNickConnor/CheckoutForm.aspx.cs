﻿using ProjectNickConnor.Logic.App_Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProjectNickConnor
{
    public partial class CheckoutForm : System.Web.UI.Page
    {
        private ReservationDBDataSet.ReservationDataTable _reservationTable = new ReservationDBDataSet.ReservationDataTable();
        protected void Page_Load(object sender, EventArgs e)
        {
            GridView1.DataSource = _reservationTable;
            GridView1.DataBind();
        }
    }
}