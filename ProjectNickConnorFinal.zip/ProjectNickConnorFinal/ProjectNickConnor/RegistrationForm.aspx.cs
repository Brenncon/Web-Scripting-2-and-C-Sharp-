﻿using ProjectNickConnor.Logic.App_Data.ReservationDBDataSetTableAdapters;
using ProjectNickConnor.Logic.App_Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ProjectNickConnor.Logic.App_Data.RegistrationDBDataSetTableAdapters;
using System.Windows.Forms;

//Author Connor Brennan

namespace ProjectNickConnor
{
    /// <summary>
    /// This is the Registeration class that allows users to add
    /// themselfs as offical users into the Users database
    /// </summary>
    public partial class RegistrationForm : System.Web.UI.Page
    {
        private RegisterTableAdapter _tableAdapter = new RegisterTableAdapter();
        private RegistrationDBDataSet _dataset = new RegistrationDBDataSet();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Gets the users name and password and sends it to the User 
        /// class to be added to the Users database table
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Register_Button_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {

                    RegistrationDBDataSet.RegisterRow register;
                    register = _dataset.Register.NewRegisterRow();
                    _tableAdapter.Insert(Username_Txt.Text, Password_Txt.Text);

                    string message = "You will be redirected to the login form now.";
                    string caption = "Account Successfully Created";
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    DialogResult result;
                    result = MessageBox.Show(message, caption, buttons);

                    Response.Redirect("Login.aspx", false);
                }
            }
            catch (Exception ex)
            {
                TxtStatus.Text = "Create account failed";
            }
        }
    }
}