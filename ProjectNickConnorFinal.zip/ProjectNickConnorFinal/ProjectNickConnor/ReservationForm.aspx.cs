﻿using ProjectNickConnor.Logic.App_Data;
using ProjectNickConnor.Logic.App_Data.ReservationDBDataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace ProjectNickConnor
{
    public partial class Reservation : System.Web.UI.Page
    {
        private ReservationTableAdapter _tableAdapter = new ReservationTableAdapter();
        private ReservationDBDataSet _dataset = new ReservationDBDataSet();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Reserve_B_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {

                    ReservationDBDataSet.ReservationRow reservation;
                    reservation = _dataset.Reservation.NewReservationRow();

                    _tableAdapter.Insert(Firstname_Txt.Text, DateTime.Parse(Startdate.Text),
                        DateTime.Parse(Enddate.Text), "Open", Lastname_Txt.Text);

                    const string message = "Would you like to make another reservation?";
                    const string caption = "Reservation Successfully Created";
                    var result = MessageBox.Show(message, caption,
                                                 MessageBoxButtons.YesNo,
                                                 MessageBoxIcon.Question);

                    if (result == DialogResult.No)
                    {
                        Response.Redirect("CheckoutForm.aspx", false);
                    }
                }
            }
            catch (Exception ex)
            {
                TxtStatus.Text = "Create reservation failed";
            }
        }
    }
}